import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
 

@Injectable({
  providedIn: 'root'
})
export class DataService {

  constructor(private httpService : HttpClient) { }
  appOperator : any = null;
  

  loadOperatorData()
  {
    debugger;
   return  this.httpService.get('./assets/operators.json');
  }
}
