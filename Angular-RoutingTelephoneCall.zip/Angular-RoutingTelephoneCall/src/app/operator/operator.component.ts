import { Component, OnInit } from '@angular/core';
import { DataService } from '../data.service';
 

@Component({
  selector: 'app-operator',
  templateUrl: './operator.component.html',
  styleUrls: ['./operator.component.css']
})
export class OperatorComponent implements OnInit {

  constructor( private serive : DataService) {  
  
  }
  operator : any = [];
  operatorArr :any = [];
  selOperator  = "";
  selOperatorArr :any = [];

  ngOnInit() {
debugger;
    if(this.serive.appOperator != null)
    {
    this.operator = this.serive.appOperator;
debugger;
    for(let obj in this.operator)
    {
      this.operatorArr.push(obj);
    }
  }
  else
  {

    alert('Load collection from routing page !!');
  }
  }
 //Function to show the selected operator list of data
  changeData()
  {

    this.selOperatorArr = [];
    for(var obj in this.operator)
    {
      if(this.selOperator == obj)
      this.selOperatorArr = this.operator[obj] ;
    }
 }

}
